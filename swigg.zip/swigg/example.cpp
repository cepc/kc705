//example.cpp

#include "example.h"

void Example::say_hello()
{
      printf("hello");
}
