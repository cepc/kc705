//example.h
#include <iostream>
using namespace std;
class Example{
public:
void say_hello();
};